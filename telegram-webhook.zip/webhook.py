from flask import Flask, request, jsonify
import json
import os
import requests

app = Flask(__name__)

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
USER_DATA_FILE = "users.json"

def load_users():
    if not os.path.exists(USER_DATA_FILE):
        return {}
    with open(USER_DATA_FILE, "r") as f:
        return json.load(f)

def send_telegram_alert(user_id, message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": user_id, "text": message}
    requests.post(url, json=payload)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()

    print("Received alert:", data)

    ticker = data.get('ticker')
    price = data.get('price')

    if not ticker or not price:
        return jsonify({"error": "Missing fields"}), 400

    users = load_users()
    if not users:
        return jsonify({"error": "No users registered"}), 404

    for user_id in users:
        msg = f"🚨 Live Trade Alert!\nTicker: {ticker}\nPrice: {price}"
        send_telegram_alert(user_id, msg)

    return jsonify({"status": "success"}), 200

@app.route('/')
def home():
    return "✅ Webhook is live!"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=10000)
