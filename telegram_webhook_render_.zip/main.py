from flask import Flask, request, jsonify
import os
import json
import requests

app = Flask(__name__)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No JSON data received"}), 400

    ticker = data.get('ticker')
    price = data.get('price')

    if not ticker or not price:
        return jsonify({"error": "Missing ticker or price"}), 400

    message = f"📢 Trade Alert!\nTicker: {ticker}\nPrice: {price}"

    user_ids = os.getenv("USER_IDS", "")
    user_ids = user_ids.split(",") if user_ids else []

    if not user_ids:
        return jsonify({"error": "No Telegram users set"}), 404

    for user_id in user_ids:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": user_id.strip(), "text": message}
        requests.post(url, json=payload)

    return jsonify({"message": "Alert sent"}), 200

@app.route("/", methods=["GET"])
def home():
    return "Telegram Bot Webhook is Live!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 10000)))
